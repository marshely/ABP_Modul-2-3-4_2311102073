<?php

$nama = $_POST['nama'];
$email = $_POST['email'];
$pertanyaan = $_POST['pertanyaan'];

?>

<!DOCTYPE html>
<html>
<head>
<title>Pesan Terkirim</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="qna-container">

<h2>Pertanyaan berhasil dikirim</h2>

<p>
Terima kasih <b><?php echo $nama; ?></b>.
<br><br>
Pertanyaan Anda sudah kami terima.
<br>
Silakan tunggu jawabannya, nanti akan dikirim melalui email.
</p>

</div>

</body>
</html>